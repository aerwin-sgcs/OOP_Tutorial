IRONWALL — Game Creation starter pack
=====================================

Open this game_creation folder in PyCharm. Everything is organised for you.

Files
-----
  ironwall.py         <- YOUR text game. Follow PAGE 2 and PAGE 3 in the tutorial.
  ironwall_visual.py  <- YOUR pygame game. Follow PAGE 4 (>>> YOUR TURN <<< markers).
  game_characters.py  <- Your defenders (Warrior/Archer/Thief). Do NOT edit.
  assets/             <- All the images, already sorted for you.

How to run
----------
  Text version:    python3 ironwall.py
  Visual version:  pip3 install pygame   (once), then   python3 ironwall_visual.py

Look for the  >>> YOUR TURN <<<  and  PAGE 2 / PAGE 3 / PAGE 4  markers —
that is where your code goes. Follow along in the Game Creation tutorial.
